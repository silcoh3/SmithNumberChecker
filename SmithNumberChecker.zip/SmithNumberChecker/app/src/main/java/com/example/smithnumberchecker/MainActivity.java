package com.example.smithnumberchecker;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText numberInput;
    private Button checkButton;
    private TextView resultText;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        numberInput = findViewById(R.id.numberInput);
        checkButton = findViewById(R.id.checkButton);
        resultText = findViewById(R.id.resultText);

        checkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String input = numberInput.getText().toString();
                if (!input.isEmpty()) {
                    int number = Integer.parseInt(input);
                    if (isSmithNumber(number)) {
                        resultText.setText(number + " is a Smith number.");
                    } else {
                        resultText.setText(number + " is not a Smith number.");
                    }
                } else {
                    resultText.setText("Please enter a number.");
                }
            }

            private boolean isSmithNumber(int number) {
                if (isPrime(number)) return false;

                int sumDigitsNum = sumOfDigits(number);
                List<Integer> primeFactors = getPrimeFactors(number);

                int sumDigitsFactors = 0;
                for (int factor : primeFactors) {
                    sumDigitsFactors += sumOfDigits(factor);
                }

                return sumDigitsNum == sumDigitsFactors;
            }

            private boolean isPrime(int num) {
                if (num <= 1) return false;
                for (int i = 2; i <= Math.sqrt(num); i++) {
                    if (num % i == 0) return false;
                }
                return true;
            }

            private int sumOfDigits(int num) {
                int sum = 0;
                while (num > 0) {
                    sum += num % 10;
                    num /= 10;
                }
                return sum;
            }

            private List<Integer> getPrimeFactors(int num) {
                List<Integer> factors = new ArrayList<>();
                for (int i = 2; i <= num; i++) {
                    while (num % i == 0) {
                        factors.add(i);
                        num /= i;
                    }
                }
                return factors;
            }


        });

        ;
    }
}